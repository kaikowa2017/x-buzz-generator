# 世界怪異監視機構 Kindle連動ゲーム

Kindle本『世界怪異監視機構ファイル Vol.1』の26ページに掲載するURL用の、読者専用Webゲームです。

監視員コードを入力すると、10件の怪異報告を順番に調査できます。

## 監視員コード

監視員コードはKindle本26ページに記載してください。

## ローカル確認

このフォルダで以下を実行します。

```bash
python3 -m http.server 4173 -d public
```

ブラウザで開きます。

```text
http://localhost:4173
```

## Netlify公開手順

一番簡単な方法は Netlify Drop です。

1. <https://app.netlify.com/drop> を開く
2. このフォルダ内の `public/` フォルダをドラッグ&ドロップする
3. 発行されたURLをKindle本の26ページに掲載する

リポジトリ連携で公開する場合は、このフォルダをNetlifyに接続してください。

- Build command: 空欄
- Publish directory: `public`

`netlify.toml` も同梱しています。
