const ACCESS_CODE = "OMEGA-001";

const form = document.querySelector("#code-form");
const input = document.querySelector("#code-input");
const statusMessage = document.querySelector("#status-message");
const accessPanel = document.querySelector("#access-panel");
const readyPanel = document.querySelector("#ready-panel");

form.addEventListener("submit", (event) => {
  event.preventDefault();

  const enteredCode = input.value.trim().toUpperCase();

  if (enteredCode === ACCESS_CODE) {
    statusMessage.textContent = "監視員コードを確認しました。";
    statusMessage.classList.add("ok");
    accessPanel.classList.add("hidden");
    readyPanel.classList.remove("hidden");
    return;
  }

  statusMessage.textContent = "監視員コードが一致しません";
  statusMessage.classList.remove("ok");
});
