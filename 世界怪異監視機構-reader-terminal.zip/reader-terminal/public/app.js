const ACCESS_CODE = "OMEGA-001";
const STORAGE_KEY = "wmba-game-save-v1";

const reports = [
  {
    id: "001",
    title: "誰もいない部屋",
    image: "/images/report-001.png",
    reportText: "深夜2時13分。空室の監視カメラが動体検知を記録した。\n管理会社の記録では、その部屋は3か月前から無人のはずだった。",
    evidenceList: [
      { title: "証拠A", text: "監視カメラ画像に、中央付近の影の揺らぎが確認されている。" },
      { title: "証拠B", text: "鍵の開閉記録は存在しない。" },
      { title: "証拠C", text: "隣室の住人は「誰かが床を歩く音を聞いた」と証言している。" }
    ],
    correctChoice: "判定不能",
    explanation: "映像に不自然な影はあるが、機材不良や外部光の可能性も排除できない。現時点では怪異と断定せず、判定不能として記録する。",
    fileName: "空室反応型：うつろべや",
    dangerRank: "C",
    category: "残留反応型",
    location: "無人の集合住宅",
    countermeasure: "深夜の単独確認は避け、複数人で記録を照合すること。"
  },
  {
    id: "002",
    title: "閉まらないクローゼット",
    image: "/images/report-002.png",
    reportText: "古い住宅の寝室にあるクローゼットが、毎晩2時13分になると数センチだけ開く。",
    evidenceList: [
      { title: "証拠A", text: "扉の内側から押されたような痕跡がある。" },
      { title: "証拠B", text: "蝶番と床に異常は確認されていない。" },
      { title: "証拠C", text: "住人は「中から衣擦れの音がする」と証言している。" }
    ],
    correctChoice: "怪異",
    explanation: "物理的な故障が確認されず、発生時刻も一定であるため、監視機構では怪異性ありとして記録する。",
    fileName: "収納潜伏型：ひらき戸",
    dangerRank: "B",
    category: "潜伏干渉型",
    location: "民家の寝室",
    countermeasure: "扉を無理に固定せず、開閉時刻と音声を記録すること。"
  },
  {
    id: "003",
    title: "深夜の学校廊下",
    image: "/images/report-003.png",
    reportText: "午後11時47分、無人の校舎内で足音が録音された。",
    evidenceList: [
      { title: "証拠A", text: "廊下奥に人影のような映像が残っている。" },
      { title: "証拠B", text: "警備ログに侵入記録はない。" },
      { title: "証拠C", text: "教員は「以前から同じ時間に足音がする」と話している。" }
    ],
    correctChoice: "怪異",
    explanation: "侵入記録がなく、複数日にわたり同様の音声が記録されているため、反復性のある怪異報告として登録する。",
    fileName: "校舎巡回型：夜歩き",
    dangerRank: "B",
    category: "残留行動型",
    location: "深夜の学校廊下",
    countermeasure: "音が近づいても呼びかけず、退路を確保すること。"
  },
  {
    id: "004",
    title: "旅館の鏡",
    image: "/images/report-004.png",
    reportText: "山間部の古い旅館で、鏡の中だけ宿泊客の表情が遅れて変わるという報告がある。",
    evidenceList: [
      { title: "証拠A", text: "鏡に映った人物の視線が実物と一致していない。" },
      { title: "証拠B", text: "鏡そのものに破損や加工の痕跡はない。" },
      { title: "証拠C", text: "複数の宿泊客が「自分ではない顔を見た」と証言している。" }
    ],
    correctChoice: "怪異",
    explanation: "複数証言と映像記録が一致しており、反射面を介した干渉型怪異として登録する。",
    fileName: "反射干渉型：鏡宿り",
    dangerRank: "A",
    category: "反射干渉型",
    location: "古い旅館の洗面所",
    countermeasure: "深夜に鏡を長時間見続けないこと。"
  },
  {
    id: "005",
    title: "エレベーターの13階",
    image: "/images/report-005.png",
    reportText: "13階が存在しない建物のエレベーターで、深夜だけ13階ボタンが点灯する。",
    evidenceList: [
      { title: "証拠A", text: "操作盤に存在しない階数表示が記録されている。" },
      { title: "証拠B", text: "管理図面に13階は存在しない。" },
      { title: "証拠C", text: "警備員は「その階で誰かが降りる音を聞いた」と証言している。" }
    ],
    correctChoice: "判定不能",
    explanation: "表示異常の可能性はあるが、図面と証言の不一致が大きい。追加調査が必要なため判定不能とする。",
    fileName: "階層逸脱型：十三階",
    dangerRank: "B",
    category: "空間異常型",
    location: "夜間のエレベーター",
    countermeasure: "存在しない階で扉が開いても降りないこと。"
  },
  {
    id: "006",
    title: "帰ってこない自撮り",
    image: "/images/report-006.png",
    reportText: "友人に送られた自撮り写真の背景に、撮影場所とは違う部屋が写っていた。",
    evidenceList: [
      { title: "証拠A", text: "写真の背景に知らない扉が確認されている。" },
      { title: "証拠B", text: "撮影時刻と位置情報は本人の部屋を示している。" },
      { title: "証拠C", text: "送信後、本人からの返信が一時的に途絶えた。" }
    ],
    correctChoice: "判定不能",
    explanation: "画像加工や通信異常の可能性も残るため、現時点では判定不能。ただし背景差異は要監視とする。",
    fileName: "背景置換型：戻らぬ自撮り",
    dangerRank: "B",
    category: "記録干渉型",
    location: "個人端末内の写真",
    countermeasure: "違和感のある写真は削除せず、原本を保管すること。"
  },
  {
    id: "007",
    title: "消えた同級生",
    image: "/images/report-007.png",
    reportText: "卒業写真に、在籍記録のない生徒が一人だけ写っていた。",
    evidenceList: [
      { title: "証拠A", text: "集合写真の後列に不明人物が確認されている。" },
      { title: "証拠B", text: "当時の名簿に該当者はいない。" },
      { title: "証拠C", text: "複数の卒業生が「その子を知っている気がする」と証言した。" }
    ],
    correctChoice: "怪異",
    explanation: "記録上存在しない人物に対し、複数人が曖昧な記憶を共有しているため、記憶干渉型怪異として登録する。",
    fileName: "記憶混入型：名無しの同級生",
    dangerRank: "A",
    category: "記憶干渉型",
    location: "卒業写真",
    countermeasure: "名前を思い出そうとし続けないこと。"
  },
  {
    id: "008",
    title: "夜のコンビニ",
    image: "/images/report-008.png",
    reportText: "深夜のコンビニ防犯カメラに、毎晩同じ時刻、同じ客が映り込む。",
    evidenceList: [
      { title: "証拠A", text: "人物は毎回同じ商品棚の前で停止する。" },
      { title: "証拠B", text: "レジ記録に購入履歴はない。" },
      { title: "証拠C", text: "店員は「目を離すと消える」と証言している。" }
    ],
    correctChoice: "怪異",
    explanation: "映像記録と店員証言が一致し、購入記録が存在しないため、出現型怪異として登録する。",
    fileName: "反復来店型：午前二時の客",
    dangerRank: "B",
    category: "反復出現型",
    location: "深夜営業の店舗",
    countermeasure: "視線を合わせず、映像記録を優先すること。"
  },
  {
    id: "009",
    title: "公園のブランコ",
    image: "/images/report-009.png",
    reportText: "無風の夜、公園のブランコが一台だけ揺れ続けている。",
    evidenceList: [
      { title: "証拠A", text: "周囲の木々や他の遊具は動いていない。" },
      { title: "証拠B", text: "監視カメラには人物の接近が記録されていない。" },
      { title: "証拠C", text: "近隣住民は「子どもの笑い声を聞いた」と証言している。" }
    ],
    correctChoice: "怪異",
    explanation: "外的要因が確認できず、音声証言も一致するため、局所運動型怪異として登録する。",
    fileName: "遊具反応型：ひとり揺れ",
    dangerRank: "C",
    category: "局所運動型",
    location: "夜の公園",
    countermeasure: "揺れを止めようとしないこと。"
  },
  {
    id: "010",
    title: "最後の留守電",
    image: "/images/report-010.png",
    reportText: "解約済みの番号から、深夜に留守電が届いた。",
    evidenceList: [
      { title: "証拠A", text: "発信元番号は既に使用停止済みだった。" },
      { title: "証拠B", text: "録音にはかすれた声と室内音が含まれている。" },
      { title: "証拠C", text: "最後に「まだ終わっていない」と聞こえる。" }
    ],
    correctChoice: "怪異",
    explanation: "停止済み番号からの着信記録が残っており、通常の通信異常だけでは説明できない。通信干渉型怪異として登録する。",
    fileName: "通信残響型：最後の留守電",
    dangerRank: "A",
    category: "通信干渉型",
    location: "個人端末",
    countermeasure: "折り返し発信は行わず、録音データを保管すること。"
  }
];

const defaultSave = {
  authenticated: false,
  clearedReports: [],
  unlockedFiles: [],
  judgments: [],
  lastStageId: "001"
};

let state = loadSave();
let route = { name: state.authenticated ? "home" : "title" };
let routeStack = [];

function loadSave() {
  try {
    return { ...defaultSave, ...JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}") };
  } catch {
    return { ...defaultSave };
  }
}

function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function isCleared(id) {
  return state.clearedReports.includes(id);
}

function isReportUnlocked(index) {
  return index === 0 || isCleared(reports[index - 1].id);
}

function areAllReportsCleared() {
  return reports.every((report) => isCleared(report.id));
}

function imageCard(src, label) {
  if (!src) {
    return `<div class="card image-card"><div class="no-image">画像記録なし</div><div class="image-label">${label}</div></div>`;
  }
  return `
    <div class="card image-card">
      <button class="record-image-button" data-open-image="${src}" data-label="${label}" aria-label="${label}を拡大表示">
        <img class="record-image" src="${src}" alt="${label}" loading="lazy" onerror="this.closest('.image-card').innerHTML='<div class=&quot;no-image&quot;>画像記録なし</div><div class=&quot;image-label&quot;>${label}</div>'" />
      </button>
      <div class="image-label">${label}</div>
    </div>
  `;
}

function shell(content, active = "home") {
  return `
    <main class="app-shell">
      <div class="topbar">
        <button class="icon-btn" data-action="back" aria-label="戻る">‹</button>
        <div class="topbar-title"><span>WORLD KAIKI MONITORING BUREAU</span><h1>世界怪異監視機構</h1></div>
        <button class="icon-btn" data-route="settings" aria-label="設定">⚙</button>
      </div>
      ${content}
    </main>
    <nav class="nav" aria-label="主要画面">
      ${navButton("home", "ホーム", active)}
      ${navButton("reports", "調査", active)}
      ${navButton("files", "図鑑", active)}
      ${navButton("settings", "設定", active)}
    </nav>
  `;
}

function navButton(name, label, active) {
  return `<button class="${active === name ? "active" : ""}" data-route="${name}">${label}</button>`;
}

function render() {
  const app = document.querySelector("#app");
  if (!app) return;

  if (route.name !== "title" && route.name !== "auth" && !state.authenticated) {
    route = { name: "title" };
  }

  const views = {
    title: renderTitle,
    auth: renderAuth,
    home: renderHome,
    reports: renderReports,
    report: renderReportDetail,
    judge: renderJudge,
    result: renderResult,
    files: renderFiles,
    file: renderFileDetail,
    afterword: renderAfterword,
    settings: renderSettings,
    terms: renderTerms,
    privacy: renderPrivacy
  };

  app.innerHTML = views[route.name]();
}

function renderTitle() {
  return `
    <main class="title-screen">
      <section class="title-panel">
        <div class="agency-mark">CLASSIFIED TERMINAL</div>
        <h1>世界怪異<br />監視機構</h1>
        <p class="lead">未確認現象、都市伝説、怪異報告を記録してください。</p>
        <button class="primary" data-route="${state.authenticated ? "home" : "auth"}">監視端末を起動</button>
      </section>
    </main>
  `;
}

function renderAuth() {
  return `
    <main class="app-shell no-nav">
      <section class="card card-pad auth-card">
        <span class="meta">READER ACCESS</span>
        <h2>読者専用：監視端末アクセス</h2>
        <p class="body-text">監視員コードを入力してください。</p>
        <form class="auth-form" data-auth-form>
          <label class="label" for="access-code">監視員コード</label>
          <input id="access-code" name="code" type="text" inputmode="latin" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="例：XXXX-000" />
          <button class="primary" type="submit">認証する</button>
          <p class="status" id="auth-status" role="status" aria-live="polite"></p>
        </form>
      </section>
    </main>
  `;
}

function renderHome() {
  const cleared = state.clearedReports.length;
  const remaining = reports.length - cleared;
  const allCleared = areAllReportsCleared();
  return shell(`
    <section class="grid">
      <div class="grid status-grid">
        <div class="card stat"><strong>${ACCESS_CODE}</strong><span>監視員ID</span></div>
        <div class="card stat"><strong>${cleared}/${reports.length}</strong><span>記録済み怪異</span></div>
        <div class="card stat"><strong>${remaining}</strong><span>本日の未確認報告</span></div>
      </div>
      ${allCleared ? `
        <div class="card card-pad result-banner">
          <span class="meta">ALL REPORTS CLEARED</span>
          <h2>記録後報告が解放されました</h2>
          <p class="body-text">すべての怪異報告の記録が完了しました。監視員への最終報告を確認できます。</p>
          <button class="primary" data-route="afterword">監視員への記録後報告へ進む</button>
        </div>
      ` : ""}
      <div class="card card-pad">
        <span class="meta">MONITORING CONSOLE</span>
        <h2>監視端末ホーム</h2>
        <p class="body-text">Kindle本『世界怪異監視機構ファイル Vol.1』と連動した調査ログです。解放済みの報告から順に確認してください。</p>
      </div>
      <button class="primary" data-route="reports">調査ファイルを見る</button>
      <button class="secondary" data-route="files">怪異図鑑を見る</button>
      <button class="secondary" data-route="settings">設定</button>
    </section>
  `, "home");
}

function renderReports() {
  return shell(`
    <section class="grid">
      ${reports.map((report, index) => {
        const unlocked = isReportUnlocked(index);
        const cleared = isCleared(report.id);
        return `
          <article class="card report-card ${unlocked ? "" : "locked"}">
            <div class="report-head">
              <div>
                <span class="meta">REPORT ${report.id}</span>
                <h3>${report.title}</h3>
              </div>
              <span class="badge">${cleared ? "記録済み" : unlocked ? "未調査" : "封鎖中"}</span>
            </div>
            <p class="report-text">${unlocked ? report.reportText : "前段階の調査記録が必要です。"}</p>
            <button class="secondary" ${unlocked ? `data-report="${report.id}"` : "disabled"}>${unlocked ? "調査ファイルを開く" : "封鎖中"}</button>
          </article>
        `;
      }).join("")}
    </section>
  `, "reports");
}

function renderReportDetail() {
  const report = getReport();
  return shell(`
    <section class="grid">
      ${imageCard(report.image, "証拠画像")}
      <div class="card card-pad">
        <span class="meta">REPORT ${report.id}</span>
        <h2>${report.title}</h2>
        <p class="report-text">${report.reportText}</p>
      </div>
      ${report.evidenceList.map((item) => `
        <article class="card card-pad evidence-item">
          <h3>${item.title}</h3>
          <p class="evidence-text">${item.text}</p>
        </article>
      `).join("")}
      <button class="primary" data-route="judge" data-id="${report.id}">判定へ進む</button>
      <button class="secondary" data-route="reports">調査一覧へ戻る</button>
    </section>
  `, "reports");
}

function renderJudge() {
  const report = getReport();
  return shell(`
    <section class="grid">
      <div class="card card-pad">
        <span class="meta">REPORT ${report.id}</span>
        <h3>判定選択</h3>
        <p class="body-text">報告文と証拠A・B・Cをもとに、監視員としての暫定判定を登録してください。</p>
      </div>
      <div class="choice-list">
        ${["怪異", "人為的", "判定不能"].map((choice) => `<button class="danger-choice" data-judge="${choice}" data-id="${report.id}">${choice}</button>`).join("")}
      </div>
      <button class="secondary" data-report="${report.id}">調査詳細へ戻る</button>
    </section>
  `, "reports");
}

function renderResult() {
  const report = getReport();
  const selected = route.choice || "判定不能";
  const correct = selected === report.correctChoice;
  const allCleared = areAllReportsCleared();
  const nextReport = reports.find((item, index) => isReportUnlocked(index) && !isCleared(item.id));
  return shell(`
    <section class="grid">
      <div class="card card-pad result-banner ${correct ? "correct" : "incorrect"}">
        <span class="meta">判定結果</span>
        <h2>${correct ? "正解" : "不正解"}</h2>
        <p class="report-text">選択: ${selected}<br />正規判定: ${report.correctChoice}</p>
        <p class="file-unlock">怪異ファイル登録</p>
      </div>
      <div class="card card-pad">
        <h3>解説</h3>
        <p class="body-text">${report.explanation}</p>
      </div>
      ${allCleared ? `
        <div class="card card-pad result-banner correct">
          <span class="meta">FINAL CLEARANCE</span>
          <h2>全調査完了</h2>
          <p class="body-text">すべての怪異報告の記録が完了しました。<br />監視員への最終報告を確認できます。</p>
          <button class="primary" data-action="afterword-complete">監視員への記録後報告へ進む</button>
        </div>
      ` : ""}
      ${!allCleared && nextReport ? `<button class="primary" data-report="${nextReport.id}">次の調査へ進む</button>` : ""}
      <button class="secondary" data-route="home">ホームへ戻る</button>
    </section>
  `, "reports");
}

function renderFiles() {
  return shell(`
    <section class="grid">
      ${reports.map((report) => {
        const unlocked = state.unlockedFiles.includes(report.id);
        return `
          <article class="card report-card ${unlocked ? "" : "locked"}">
            <div class="report-head">
              <div>
                <span class="meta">FILE ${report.id}</span>
                <h3>${unlocked ? report.fileName : "未記録"}</h3>
              </div>
              <span class="badge">危険度 ${unlocked ? report.dangerRank : "-"}</span>
            </div>
            <p class="report-text">${unlocked ? `${report.category} / ${report.location}` : "調査完了後に登録されます。"}</p>
            <button class="secondary" ${unlocked ? `data-file="${report.id}"` : "disabled"}>${unlocked ? "怪異詳細を見る" : "未記録"}</button>
          </article>
        `;
      }).join("")}
    </section>
  `, "files");
}

function renderFileDetail() {
  const report = getReport();
  return shell(`
    <section class="grid">
      ${imageCard(report.image, "怪異ファイル画像")}
      <div class="card card-pad">
        <span class="meta">FILE ${report.id}</span>
        <h2>${report.fileName}</h2>
        <p class="body-text">報告番号: ${report.id}<br />危険度: ${report.dangerRank}<br />分類: ${report.category}<br />発生場所: ${report.location}</p>
      </div>
      <div class="card card-pad"><h3>概要</h3><p class="body-text">${report.explanation}</p></div>
      <div class="card card-pad"><h3>対処メモ</h3><p class="body-text">${report.countermeasure}</p></div>
    </section>
  `, "files");
}

function renderAfterword() {
  if (!areAllReportsCleared()) {
    return shell(`<section class="card card-pad"><h2>監視員への記録後報告</h2><p class="body-text">全調査完了後に閲覧できます。</p></section>`, "settings");
  }
  const body = `ここまで調査してくださり、ありがとうございます。

『世界怪異監視機構』は、
世界各地に残された不思議な噂や、
説明のつかない現象を“記録”として集めていくための監視端末です。

このアプリは、
『世界怪異監視機構ファイル Vol.1』と連動した読者用コンテンツとして制作しました。

本で読んだ怪異を、
今度は自分の手で調査し、分類し、記録する。

そんな体験を楽しんでもらえたら嬉しいです。

ここにある怪異報告は架空の記録ですが、
誰かが怖いと感じた記憶や、
説明できない違和感もまた、
ひとつの怪異なのかもしれません。

記録は、まだ終わっていません。

世界怪異監視機構
記録管理室`;
  return shell(`<section class="card card-pad afterword-card"><span class="meta">POST INVESTIGATION REPORT</span><h2>監視員への記録後報告</h2><p class="afterword-text">${body}</p></section>`, "settings");
}

function renderSettings() {
  const allCleared = areAllReportsCleared();
  return shell(`
    <section class="grid">
      <div class="card card-pad">
        <h2>設定</h2>
        <p class="body-text">端末情報と補助資料を確認できます。</p>
      </div>
      <button class="secondary" data-action="reset-auth">認証リセット</button>
      <button class="secondary" data-action="reset-progress">進行状況リセット</button>
      ${allCleared ? `<button class="secondary" data-route="afterword">監視員への記録後報告</button>` : `<button class="secondary" disabled>全調査完了後に閲覧できます</button>`}
      <button class="secondary" data-route="terms">利用規約</button>
      <button class="secondary" data-route="privacy">プライバシーポリシー</button>
    </section>
  `, "settings");
}

function renderTerms() {
  return shell(`<section class="card card-pad terms"><h2>利用規約</h2><p>本アプリは創作ホラーコンテンツです。実在の事件・人物・団体とは関係ありません。無断転載・再配布を禁止します。内容の正確性を保証しません。本アプリは『世界怪異監視機構ファイル Vol.1』の世界観を補足する連動コンテンツです。</p></section>`, "settings");
}

function renderPrivacy() {
  return shell(`<section class="card card-pad terms"><h2>プライバシーポリシー</h2><p>本アプリは個人情報を収集しません。進行状況と認証状態はブラウザの localStorage に保存します。入力された監視員コードは外部送信しません。今後アクセス解析などを導入する場合は内容を追記します。</p></section>`, "settings");
}

function getReport(id = route.id) {
  return reports.find((report) => report.id === id) || reports[0];
}

function navigate(name, id, choice, options = {}) {
  if (name === "afterword" && !areAllReportsCleared()) name = "home";
  if (!options.replace) routeStack.push(route);
  route = { name, id, choice, backHome: options.backHome || false };
  render();
  window.scrollTo({ top: 0, behavior: "instant" });
}

function goBack() {
  if (route.name === "afterword" && route.backHome) {
    routeStack = [];
    route = { name: "home" };
  } else {
    route = routeStack.pop() || { name: "home" };
  }
  render();
  window.scrollTo({ top: 0, behavior: "instant" });
}

function completeJudgment(id, choice) {
  const report = getReport(id);
  const correct = choice === report.correctChoice;
  if (!state.clearedReports.includes(id)) state.clearedReports.push(id);
  if (!state.unlockedFiles.includes(id)) state.unlockedFiles.push(id);
  state.lastStageId = id;
  state.judgments = state.judgments.filter((item) => item.id !== id);
  state.judgments.push({ id, choice, correctChoice: report.correctChoice, correct, at: new Date().toISOString() });
  save();
  navigate("result", id, choice);
}

function openImage(src, label) {
  const modal = document.querySelector("#image-modal");
  modal.className = "image-modal open";
  modal.setAttribute("aria-hidden", "false");
  modal.innerHTML = `<button class="secondary" data-close-image>閉じる</button><img src="${src}" alt="${label}" /><div class="modal-caption">${label}</div>`;
}

function closeImage() {
  const modal = document.querySelector("#image-modal");
  modal.className = "image-modal";
  modal.setAttribute("aria-hidden", "true");
  modal.innerHTML = "";
}

document.addEventListener("submit", (event) => {
  const form = event.target.closest("[data-auth-form]");
  if (!form) return;
  event.preventDefault();
  const code = new FormData(form).get("code").trim().toUpperCase();
  const status = document.querySelector("#auth-status");
  if (code === ACCESS_CODE) {
    state.authenticated = true;
    save();
    navigate("home", undefined, undefined, { replace: true });
  } else {
    status.textContent = "監視員コードが一致しません";
  }
});

document.addEventListener("click", (event) => {
  const target = event.target.closest("button, a");
  if (!target) return;

  if (target.dataset.route) navigate(target.dataset.route, target.dataset.id);
  if (target.dataset.report) navigate("report", target.dataset.report);
  if (target.dataset.file) navigate("file", target.dataset.file);
  if (target.dataset.judge) completeJudgment(target.dataset.id, target.dataset.judge);
  if (target.dataset.openImage) openImage(target.dataset.openImage, target.dataset.label || "画像記録");
  if (target.dataset.closeImage !== undefined) closeImage();
  if (target.dataset.action === "back") goBack();
  if (target.dataset.action === "afterword-complete") navigate("afterword", undefined, undefined, { backHome: true });
  if (target.dataset.action === "reset-auth") {
    state.authenticated = false;
    save();
    navigate("title", undefined, undefined, { replace: true });
  }
  if (target.dataset.action === "reset-progress") {
    state = { ...defaultSave, authenticated: state.authenticated };
    save();
    navigate("home", undefined, undefined, { replace: true });
  }
});

render();
