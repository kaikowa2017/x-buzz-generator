# 画像管理

このフォルダに怪異報告用の画像を配置します。

## ファイル名

英数字とハイフンで管理してください。

- `report-001.png`
- `report-002.png`
- `report-003.png`
- `report-004.png`
- `report-005.png`
- `report-006.png`
- `report-007.png`
- `report-008.png`
- `report-009.png`
- `report-010.png`

## データへの追加方法

`public/app.js` の各ステージデータに `image` フィールドを設定します。

```js
{
  id: "001",
  title: "誰もいない部屋",
  image: "images/report-001.png"
}
```

画像が存在しない、または `image` が空の場合は、アプリ側で「画像記録なし」と表示されます。

## 推奨サイズ

スマホ縦画面で見やすいように、横長または正方形寄りの画像を推奨します。

- 推奨: 1200 x 900px
- 形式: PNG または JPG
- 表示: `object-fit: cover`

画像は調査詳細画面では「証拠画像」、怪異図鑑詳細画面では「怪異ファイル画像」として表示されます。
